"""Helper functions and constants for the Historical Data Load pipeline.

Contains all transformation logic, constants, and pipeline functions
used by the historical_data_load notebook.
"""

import hashlib
from datetime import datetime

import numpy as np
import pandas as pd
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation, localcontext


# ==========================================================
# Constants
# ==========================================================

COLUMN_RENAMES = {
    'Unnamed: 1': 'kpi_name',
    'Unnamed: 0': 'metric_id',
    'Measure': 'uom',
}

MISSING_KPI_START_ID = 9000

DIMENSION_PROPAGATION_MAP = {
    'K39_5': ['K39_1', 'K39_2', 'K39_3', 'K39_4', 'K39_24'],
    'K39_8': ['K39_6', 'K39_7', 'K39_22', 'K39_25'],
    'K39_11': ['K39_9', 'K39_10', 'K39_23', 'K39_27'],
    'K632_5': ['K632_2'],
    'K632_8': ['K632_6', 'K632_7'],
}

SHEET_NAMES = [
    'ACT 25-26', 'ACT MGO 25-26', 'ACT GEM 25-26',
    'FOR 25-26', 'FOR MGO 25-26', 'FOR GEM 25-26',
    'BUD 25-26', 'BUD MGO 25-26', 'BUD GEM 25-26',
    'Variance Final','ACT Final',
    'Input_GEM', 'Input_MGO','Models Final'
]

SCENARIO_MAP = {
    'ACT': 'Actuals Historic',
    'Input': 'Actuals Historic',
    'BUD': 'Budgets',
    'FOR': 'Forecast',
    'Variance':'Budgets',
    'Models':'Actuals Historic'
}

CUTOFF_DATE_MAP = {
    'ACT': datetime(2026, 2, 1),
    'Input': datetime(2026, 2, 1)

}

SUFFIX_MAP = {
    'MGO': '_5',
    'GEM': '_8',
    'default': '_12',
}

# Target KPIs to calculate via the engine
TARGET_KPIS = ['K19', 'K28', 'K27', 'K25', 'K35', 'K42', 'K36', 'K15']


# ==========================================================
# Helper Functions
# ==========================================================

def _to_decimal(x):
    """Convert value to Decimal(36,12) with wider precision for large historical values."""
    try:
        f = float(x)
        if not np.isfinite(f):
            return Decimal("0.000000000000")
        with localcontext() as ctx:
            ctx.prec = 38
            return Decimal(str(f)).quantize(Decimal("0.000000000000"), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError, OverflowError):
        return Decimal("0.000000000000")


def map_scenario(sheet_name, scenario_map):
    """Map sheet name prefix to scenario label."""
    for prefix, scenario in scenario_map.items():
        if sheet_name.startswith(prefix):
            return scenario
    return 'Unknown'


def map_cutoff_date(sheet_name, cutoff_date_map):
    """Map sheet name prefix to cutoff date. Returns None if no prefix matches (pass all data)."""
    for prefix in cutoff_date_map:
        if prefix != 'default' and sheet_name.startswith(prefix):
            return cutoff_date_map[prefix]
    return cutoff_date_map.get('default')


def map_dim_from_source(source):
    """Derive kpi_dim_id from source sheet name."""
    if 'MGO' in source:
        return '5'
    elif 'GEM' in source:
        return '8'
    else:
        return '12'


def map_suffix(source, suffix_map):
    """Map source file to metric_id suffix."""
    for key in suffix_map:
        if key != 'default' and key in source:
            return suffix_map[key]
    return suffix_map['default']


def remove_near_duplicates(df):
    """Remove near-duplicate values (<1 diff) for same metric_id, scenario, date_key."""
    df_sorted = df.sort_values(
        ['metric_id', 'scenario', 'date_key', 'value'],
        ascending=[True, True, True, False]
    )

    def filter_group(group):
        values = group['value'].tolist()
        keep = []
        for i, v in enumerate(values):
            if all(abs(v - values[j]) >= 1 for j in range(i)):
                keep.append(i)
        return group.iloc[keep]

    return (
        df_sorted
        .groupby(['metric_id', 'scenario', 'date_key'], group_keys=False)
        .apply(lambda g: filter_group(g))
        .reset_index(drop=True)
    )


def transform_sheet_df(sheet_df, sheet_name, cutoff_date, scenario_map, include_metric=True):
    """Melt an Excel sheet from wide to long format with fiscal period columns."""
    date_columns = [
        col for col in sheet_df.columns
        if isinstance(col, datetime) and (cutoff_date is None or col <= cutoff_date)
    ]
    identifier_columns = ['kpi_name', 'uom']
    if include_metric:
        identifier_columns = ['metric_id'] + identifier_columns

    sheet_transformed_df = sheet_df[identifier_columns + date_columns]
    sheet_melted_df = sheet_transformed_df.melt(
        id_vars=identifier_columns,
        var_name='date',
        value_name='value'
    )
    sheet_melted_df['date'] = pd.to_datetime(sheet_melted_df['date'])
    sheet_melted_df['date_key'] = sheet_melted_df['date'].dt.strftime('%Y-%m-%d')
    sheet_melted_df['fiscal_year'] = sheet_melted_df['date'].dt.year + (sheet_melted_df['date'].dt.month >= 7)
    sheet_melted_df['fiscal_month'] = ((sheet_melted_df['date'].dt.month - 7) % 12) + 1
    sheet_melted_df['scenario'] = map_scenario(sheet_name, scenario_map)
    sheet_melted_df['source_file'] = sheet_name
    sheet_melted_df = sheet_melted_df.drop(columns=['date'])
    sheet_melted_df['value'] = pd.to_numeric(sheet_melted_df['value'], errors='coerce').fillna(0)
    return sheet_melted_df


# ==========================================================
# Pipeline Functions
# ==========================================================

def process_sheets(sheet_names, file_path, cutoff_date_map, scenario_map):
    """Read each Excel sheet and split into valid (has metric_id) vs missing (no metric_id) DataFrames.
    Sheets listed in sheet_names but absent from the Excel file are silently skipped.
    """
    valid_dfs, missing_dfs = [], []

    with pd.ExcelFile(file_path) as xls:
        available_sheets = set(xls.sheet_names)

    for sheet_name in sheet_names:
        if sheet_name not in available_sheets:
            print(f"  Skipping sheet not found in Excel: '{sheet_name}'")
            continue
        sheet_df = pd.read_excel(file_path, sheet_name=sheet_name, header=3).rename(columns=COLUMN_RENAMES)
        cutoff_date = map_cutoff_date(sheet_name, cutoff_date_map)

        valid_mask = sheet_df['metric_id'].notna() & (sheet_df['metric_id'] != "")
        missing_mask = sheet_df['metric_id'].isna() & sheet_df['kpi_name'].notna() & sheet_df['uom'].notna()

        if valid_mask.any():
            valid_sheet = sheet_df[valid_mask].copy()
            num_cols = valid_sheet.select_dtypes(include='number').columns
            valid_sheet[num_cols] = valid_sheet[num_cols].fillna(0)
            valid_dfs.append(
                transform_sheet_df(valid_sheet, sheet_name, cutoff_date, scenario_map, include_metric=True)
            )
        if missing_mask.any():
            missing_dfs.append(
                transform_sheet_df(sheet_df[missing_mask].copy(), sheet_name, cutoff_date, scenario_map, include_metric=False)
            )

    return valid_dfs, missing_dfs


def handle_valid_kpis(valid_dfs):
    """Combine valid KPI DataFrames and apply standard transformations."""
    if not valid_dfs:
        return pd.DataFrame()
    df = pd.concat(valid_dfs, ignore_index=True)
    df = df.rename(columns={'kpi_name': 'name'})
    df['value'] = df['value'].apply(_to_decimal)
    df = df.drop_duplicates(subset=['metric_id', 'value', 'date_key', 'scenario'])
    df['metric_id'] = df['metric_id'].astype(str)
    return df


def handle_missing_kpis(missing_dfs, suffix_map, start_id=MISSING_KPI_START_ID):
    """Assign synthetic metric IDs (K9000+) and pre-fill metadata for KPIs not in master."""
    if not missing_dfs:
        return pd.DataFrame()
    missing_df = pd.concat(missing_dfs, ignore_index=True)
    unique_kpis = missing_df[['kpi_name', 'uom']].drop_duplicates().reset_index(drop=True)
    unique_kpis['metric_id'] = [f'K{i}' for i in range(start_id, start_id + len(unique_kpis))]
    missing_df = missing_df.merge(unique_kpis, on=['kpi_name', 'uom'], how='left')
    missing_df['metric_id'] += missing_df['source_file'].apply(lambda x: map_suffix(x, suffix_map))
    missing_df['category'] = 'N/A'
    missing_df['subcategory'] = 'N/A'
    missing_df = missing_df.rename(columns={'kpi_name': 'name'})
    missing_df['value'] = missing_df['value'].apply(_to_decimal)
    missing_df = missing_df.drop_duplicates(subset=['metric_id', 'value', 'date_key', 'scenario'])
    missing_df['metric_id'] = missing_df['metric_id'].astype(str)
    return missing_df


def propagate_dimensions(df, propagation_map=None):
    """Propagate source dimension values to sub-dimensions for Actuals/Inputs Historic."""
    if propagation_map is None:
        propagation_map = DIMENSION_PROPAGATION_MAP

    actuals_mask = df['scenario'].isin(['Actuals Historic', 'Inputs Historic'])
    sources = df[actuals_mask & df['metric_id'].isin(propagation_map.keys())].copy()

    new_rows = []
    for _, row in sources.iterrows():
        for target in propagation_map[row['metric_id']]:
            new_row = row.copy()
            new_row['metric_id'] = target
            new_rows.append(new_row)

    if not new_rows:
        print("  Dimension propagation: no source rows found")
        return df

    propagated_df = pd.DataFrame(new_rows)
    all_targets = [t for targets in propagation_map.values() for t in targets]
    df = df[~(actuals_mask & df['metric_id'].isin(all_targets))]
    df = pd.concat([df, propagated_df], ignore_index=True)
    print(f"  Dimension propagation: {len(propagated_df)} rows created")
    return df


def extract_dimensions(df, kpi_dim_df):
    """Extract kpi_id, kpi_dim_id from metric_id and join location hierarchy for dim_name."""
    df['kpi_id'] = df['metric_id'].str.split('_').str[0]
    df['kpi_dim_id'] = df['metric_id'].str.split('_').str[1]
    df['kpi_dim_id'] = df.apply(
        lambda row: map_dim_from_source(row['source_file'])
        if pd.isna(row['kpi_dim_id']) or row['kpi_dim_id'] == 'NA'
        else row['kpi_dim_id'],
        axis=1
    )
    df = df.merge(
        kpi_dim_df.rename(columns={'kpi_dim_name': 'dim_name'}),
        on='kpi_dim_id', how='left'
    )
    return df


def enrich_with_master(df, kpi_master_df):
    """Join valid KPIs to KPI master for kpi_name, category, subcategory, uom.

    Two-pass approach:
      1. Exact match on (kpi_id, kpi_dim_id)
      2. Fallback for valid kpi_ids with unmatched dim: use category/subcategory/uom
         from the same kpi_id (deduped to 1 row per kpi_id to avoid many-to-many)
    """
    df['uom_original'] = df['uom']
    df = df.drop(columns=['uom'])
    df = df.merge(
        kpi_master_df[['kpi_id', 'kpi_dim_id', 'kpi_name', 'category', 'subcategory', 'uom']],
        on=['kpi_id', 'kpi_dim_id'],
        how='left'
    )

    # Fallback: for rows with valid kpi_id but missing dim match
    unmatched_mask = df['category'].isna()
    if unmatched_mask.any():
        master_fallback = (
            kpi_master_df.drop_duplicates(subset=['kpi_id'])
            [['kpi_id', 'kpi_name', 'category', 'subcategory', 'uom']]
            .rename(columns={
                'kpi_name': '_fb_kpi_name',
                'category': '_fb_category',
                'subcategory': '_fb_subcategory',
                'uom': '_fb_uom'
            })
        )
        df = df.merge(master_fallback, on='kpi_id', how='left')
        df.loc[unmatched_mask, 'kpi_name'] = df.loc[unmatched_mask, '_fb_kpi_name']
        df.loc[unmatched_mask, 'category'] = df.loc[unmatched_mask, '_fb_category']
        df.loc[unmatched_mask, 'subcategory'] = df.loc[unmatched_mask, '_fb_subcategory']
        df.loc[unmatched_mask, 'uom'] = df.loc[unmatched_mask, '_fb_uom']
        df = df.drop(columns=['_fb_kpi_name', '_fb_category', '_fb_subcategory', '_fb_uom'])

    # Backfill remaining nulls from original Excel columns
    df['kpi_name'] = df['kpi_name'].combine_first(df['name'])
    df['uom'] = df['uom'].combine_first(df['uom_original']).astype(str)
    df['category'] = df['category'].fillna('N/A')
    df['subcategory'] = df['subcategory'].fillna('N/A')

    df = df.drop(columns=['name', 'uom_original'])
    return remove_near_duplicates(df)


def build_final_df(valid_df, missing_df):
    """Combine valid and missing DataFrames and generate unique keys."""
    if not missing_df.empty:
        missing_df = missing_df.rename(columns={'name': 'kpi_name'})
        missing_df['uom'] = missing_df['uom'].astype(str)

    final_df = pd.concat([valid_df, missing_df], ignore_index=True) if not missing_df.empty else valid_df.copy()
    final_df['kpi_dim_id'] = final_df['kpi_dim_id'].astype(int)
    final_df['kpi_unique_id'] = (
        final_df['metric_id'].fillna('NA').astype(str) + '||' +
        final_df['date_key'].fillna('NA').astype(str) 
    ).apply(lambda x: hashlib.sha256(x.encode()).hexdigest())
    return final_df
