-- =============================================================================
-- View  : vw_aaa_executive_commentary
-- Schema: {{ catalog }}.{{ gold_schema }}
--
--   Parameters (injected at render time from EngineConfig):
--   catalog      : main Unity Catalog name
--   gold_schema  : gold layer schema name
--   aaa_catalog  : AAA source catalog name
--   aaa_schema   : AAA source schema name
-- =============================================================================

CREATE OR REPLACE VIEW {{ catalog }}.{{ gold_schema }}.vw_aaa_executive_commentary AS
SELECT
  t.team_id,
  t.team_name,
  a.commentary       AS annotation,
  a.created_by       AS annotation_createdby,
  a.created_at       AS annotation_createddate,
  a.month            AS reporting_month,
  a.year             AS reporting_year,
  date(CONCAT(a.year,'-',LPAD(a.month,2,'0'),'-01')) AS reporting_date
FROM
  {{ aaa_catalog }}.{{ aaa_schema }}.scr_teams t
  INNER JOIN {{ aaa_catalog }}.{{ aaa_schema }}.scr_annotation a
    ON t.team_id = a.role
