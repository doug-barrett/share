# Databricks notebook source
# DBTITLE 1,Create Views
# MAGIC %md
# MAGIC # Create Views
# MAGIC Renders all Jinja2-templated SQL files in `src/sql/` and creates (or replaces) the corresponding views in Unity Catalog.
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# Add project root to path and import modules
import sys
import os

notebook_path = os.path.dirname(
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
)
project_root = f"/Workspace{notebook_path}"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from src.config import create_config
from src.data_loader import load_all_inputs
from src.engine import run_calculation_engine

print(f"Project root: {project_root}")

# COMMAND ----------

# DBTITLE 1,Setup — paths, env loading, Jinja2 context
from datetime import date
from src.config import create_config
from src.utils import create_views
import pandas as pd
try:
    params = dbutils.widgets.getAll()
except Exception:
    params = {}

params.setdefault("env", "dev")
params.setdefault("month", str(date.today().month))
params.setdefault("year", str(date.today().year))
params.setdefault("site_code", "MGO")
cfg = create_config(params)
print(f"Environment: {params['env']} | Catalog: {cfg.catalog} | Year: {cfg.fiscal_year}")

results = create_views(spark, cfg)
display(pd.DataFrame(results)[["view", "status", "error"]])