# Databricks notebook source
# DBTITLE 1,Notebook Overview
# MAGIC %md
# MAGIC # Historical Data Load — SCR KPI Calculation Engine
# MAGIC
# MAGIC Loads historical actuals, budgets, and forecasts from the SCR Excel workbook, runs the KPI calculation engine for derived metrics, and writes results to Delta tables.
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,dependency
pip install openpyxl

# COMMAND ----------

import sys
import os
import importlib

# Add project root to sys.path so src modules are importable
notebook_path = os.path.dirname(
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
)
project_root = f"/Workspace{notebook_path}"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import pandas as pd
import numpy as np
import hashlib
from datetime import datetime, date
from decimal import Decimal, ROUND_HALF_UP
from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType

# Project module imports
import src.engine
import src.utils
from src.engine import (
    run_calculation_engine, build_lookup, build_kpi_ref_dict_map,
    build_name_lookup, replace_ids_with_names
)
from src.utils import clean_kpi_df

print(f"Project root: {project_root}")

# COMMAND ----------

# DBTITLE 1,Section: Configuration
# MAGIC %md
# MAGIC ## 2. Configuration

# COMMAND ----------

# DBTITLE 1,environment variables
# Load environment config (switch to 'uat', 'prod' etc. as needed)
importlib.reload(src.config)
from src.config import create_config
try:
    params = dbutils.widgets.getAll()
except Exception:
    params = {}
params.setdefault("env", "dev")
params.setdefault("month", "2")
params.setdefault("year", "2026")
params.setdefault("site_code", "MGO")

cfg = create_config(params)

# Core config from env file
catalog = cfg.catalog
silver_schema = cfg.silver_schema
reference_schema = cfg.reference_schema
file_path = cfg.historical_bf_excel_path

print(f"Environment: {params['env']}")
print(f"Catalog: {catalog}")
print(f"File path: {file_path}")



# COMMAND ----------

from src.historical_helpers import (
    SHEET_NAMES, SCENARIO_MAP, CUTOFF_DATE_MAP, SUFFIX_MAP,
    DIMENSION_PROPAGATION_MAP, TARGET_KPIS,
    process_sheets, handle_valid_kpis, handle_missing_kpis,
    propagate_dimensions, extract_dimensions, enrich_with_master,
    build_final_df, _to_decimal,
)

sheet_names = SHEET_NAMES
scenario_map = SCENARIO_MAP
cutoff_date_map = CUTOFF_DATE_MAP
suffix_map = SUFFIX_MAP

current_ts = datetime.now()
load_year = current_ts.year
load_month = current_ts.month

# COMMAND ----------

# DBTITLE 1,Section: Helper Functions
# MAGIC %md
# MAGIC ## 3. Helper Functions
# MAGIC Transformation utilities for sheet processing (scenario mapping, cutoff dates, deduplication).

# COMMAND ----------

# DBTITLE 1,Section: Data Loading
# MAGIC %md
# MAGIC ## 4. Data Pipeline: Load, Propagate & Enrich
# MAGIC Reads Excel sheets → assigns synthetic IDs for missing KPIs → propagates K39/K632 dimensions → joins KPI master & location hierarchy → generates unique keys.

# COMMAND ----------



# Step 1: Load and split Excel sheets
valid_dfs, missing_dfs = process_sheets(sheet_names, file_path, cutoff_date_map, scenario_map)
valid_df = handle_valid_kpis(valid_dfs)
missing_df = handle_missing_kpis(missing_dfs, suffix_map)

print(f"Step 1 — Sheets loaded: {len(sheet_names)} | Valid: {len(valid_df)} | Missing: {len(missing_df)}")

# Step 2: Propagate K39/K632 dimensions (Actuals only — valid KPIs only)
valid_df = propagate_dimensions(valid_df, DIMENSION_PROPAGATION_MAP)

# Step 3: Load reference data, extract dimensions, enrich
from src.data_loader import load_kpi_master

kpi_master_df, kpi_dim_df = load_kpi_master(spark, cfg)

kpi_dim_df['kpi_dim_id'] = kpi_dim_df['kpi_dim_id'].astype(str)
kpi_master_df['kpi_id'] = kpi_master_df['kpi_id'].astype(str)
kpi_master_df['kpi_dim_id'] = kpi_master_df['kpi_dim_id'].astype(str)

valid_df = extract_dimensions(valid_df, kpi_dim_df)
missing_df = extract_dimensions(missing_df, kpi_dim_df) if not missing_df.empty else missing_df
valid_df = enrich_with_master(valid_df, kpi_master_df)

# Step 4: Combine and generate unique keys
final_df = build_final_df(valid_df, missing_df)

print(f"Step 4 — Final DataFrame: {len(final_df)} rows (valid: {len(valid_df)}, missing: {len(missing_df)})")
print(f"  Nulls: {final_df[['kpi_name', 'category', 'dim_name']].isnull().sum().to_dict()}")





# COMMAND ----------

display(final_df.isnull().sum().reset_index().rename(columns={'index': 'attribute', 0: 'null_count'}))

# COMMAND ----------

# DBTITLE 1,Section: Calculation Engine
# MAGIC %md
# MAGIC ## 5. Calculation Engine
# MAGIC Run `src.engine.run_calculation_engine` for derived KPIs (K19, K28, K27, K25, K35, K42, K36, K15) using actuals as base lookup.

# COMMAND ----------

# DBTITLE 1,Calculation engine for derived KPIs
# Reload engine module to pick up base_lookup parameter
importlib.reload(src.engine)
from src.engine import run_calculation_engine, build_lookup, build_kpi_ref_dict_map

kpi_dim_df['name'] = kpi_dim_df['kpi_dim_name']
final_df_cols = final_df.columns.tolist()

# ------------------------------------------
# Split into 3 scenario DataFrames
# ------------------------------------------
actuals_df = final_df[final_df['scenario'].isin(['Actuals Historic', 'Inputs Historic'])].copy()
budgets_df = final_df[final_df['scenario'] == 'Budgets'].copy()
forecast_df = final_df[final_df['scenario'] == 'Forecast'].copy()

actuals_df['value_float'] = actuals_df['value'].apply(float)
budgets_df['value_float'] = budgets_df['value'].apply(float)
forecast_df['value_float'] = forecast_df['value'].apply(float)

print(f"Actuals: {len(actuals_df)} rows, {actuals_df['date_key'].nunique()} periods")
print(f"Budgets: {len(budgets_df)} rows, {budgets_df['date_key'].nunique()} periods")
print(f"Forecast: {len(forecast_df)} rows, {forecast_df['date_key'].nunique()} periods")

# ------------------------------------------
# Run engine per scenario
# ------------------------------------------
actuals_kpis = ['K19', 'K28', 'K27', 'K25', 'K35', 'K42', 'K36', 'K15']
bf_kpis = ['K15']

scenario_runs = [
    ("Actuals", actuals_df, actuals_kpis, "Actuals Historic"),
    ("Budgets", budgets_df, bf_kpis, "Budgets"),
    ("Forecast", forecast_df, bf_kpis, "Forecast"),
]

all_engine_results = []

for label, src_df, target_kpis, scenario_tag in scenario_runs:
    if src_df.empty:
        print(f"\n{label}: no data, skipping")
        continue

    engine_kpi_master = kpi_master_df[kpi_master_df['kpi_id'].isin(target_kpis)].copy()
    results_list = []

    for date_key, month_data in src_df.groupby('date_key'):
        base_lookup = {
            (str(r['kpi_id']).strip().upper(), int(r['kpi_dim_id'])): r['value_float']
            for _, r in month_data.iterrows()
        }
        fiscal_year = int(month_data['fiscal_year'].iloc[0])
        fiscal_month = int(month_data['fiscal_month'].iloc[0])
        dt = pd.to_datetime(date_key)

        results_df, _ = run_calculation_engine(
            kpi_master_df=engine_kpi_master.copy(),
            inputs_df=pd.DataFrame(columns=["input_ref", "value"]),
            kpi_ref_dict=kpi_dim_df,
            kpi_adjustments={},
            fiscal_year=fiscal_year,
            fiscal_month=fiscal_month,
            year=dt.year,
            month=dt.month,
            base_lookup=base_lookup
        )
        if not results_df.empty:
            results_df['scenario'] = scenario_tag
            results_list.append(results_df)

    if results_list:
        scenario_results = pd.concat(results_list, ignore_index=True)
        all_engine_results.append(scenario_results)
        print(f"\n{label}: {len(scenario_results)} rows calculated across {src_df['date_key'].nunique()} periods")
    else:
        print(f"\n{label}: no engine results")

# ------------------------------------------
# Append all engine results to final_df (Excel values preserved as primary)
# ------------------------------------------
if all_engine_results:
    engine_output = pd.concat(all_engine_results, ignore_index=True)
    engine_output = engine_output.rename(columns={"matrix_id": "metric_id", "kpi_engine_key": "kpi_unique_id"})
    engine_output["source_file"] = "engine"
    engine_output['date_key'] = engine_output['date_key'].astype(str)

    for col in final_df_cols:
        if col not in engine_output.columns:
            engine_output[col] = None
    engine_output = engine_output[final_df_cols]

    # Excel rows come first → keep='first' preserves Excel over engine
    final_df = pd.concat([final_df, engine_output], ignore_index=True)
    final_df = final_df.drop_duplicates(subset=['metric_id', 'date_key', 'scenario'], keep='first')

    print(f"\nEngine total: {len(engine_output)} rows appended")

print(f"final_df: {len(final_df)} total rows")

# COMMAND ----------

# DBTITLE 1,Section: Save to Tables
# MAGIC %md
# MAGIC ## 6. Save to Tables
# MAGIC Write actuals (overwrite) and budget/forecast (versioned append) to Delta.

# COMMAND ----------

# DBTITLE 1,saving to tables
# ------------------------------------------
# Save Actuals (overwrite as-is)
# ------------------------------------------

def save_actuals(final_df, catalog, silver_schema):
    actuals_df = final_df[final_df['scenario'].isin(['Actuals Historic','Inputs Historic'])].copy()
    if actuals_df.empty:
        print("Actuals skipped: no Actuals Historic data found in this load — existing table preserved.")
        return
    actuals_df['kpi_dim_id'] = actuals_df['kpi_dim_id'].astype(int)
    actuals_df['uom'] = actuals_df['uom'].astype(str)
    spark.createDataFrame(actuals_df) \
        .write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .saveAsTable(f"{catalog}.{silver_schema}.scr_actuals_historic")
    print(f"Actuals saved: {len(actuals_df)} rows → {catalog}.{silver_schema}.scr_actuals_historic")

save_actuals(final_df, catalog, silver_schema)

# COMMAND ----------

# DBTITLE 1,Save Budgets and Forecast
# ------------------------------------------
# Budgets + Forecast (VERSIONED APPEND by date_key)
# ------------------------------------------
def save_budgets_forecast(final_df, catalog, silver_schema):
    from pyspark.sql.types import DecimalType

    target_table = f"{catalog}.{silver_schema}.scr_budget_forecast"
    value_type = DecimalType(36, 12)

    budgets_forecast_df = final_df[
        final_df['scenario'].isin(['Budgets', 'Forecast'])
    ].copy()
    budgets_forecast_df['kpi_dim_id'] = budgets_forecast_df['kpi_dim_id'].astype(int)
    budgets_forecast_df['uom'] = budgets_forecast_df['uom'].astype(str)

    if budgets_forecast_df.empty:
        print("Budgets/Forecast skipped: no Budget or Forecast data found in this load — existing table preserved.")
        return

    # Determine next version_id based on max version for the current date_key
    current_date_key = budgets_forecast_df["date_key"].iloc[0]

    if spark.catalog.tableExists(target_table):
        max_version = spark.sql(
            f"SELECT COALESCE(MAX(version_id), 0) AS max_v FROM {target_table} WHERE date_key = '{current_date_key}'"
        ).collect()[0]["max_v"]
        version_id = max_version + 1
    else:
        version_id = 1

    # Add metadata columns
    budgets_forecast_df["version_id"] = version_id
    budgets_forecast_df["load_ts"] = current_ts
    budgets_forecast_df["load_year"] = load_year
    budgets_forecast_df["load_month"] = load_month

    # Cast value to string to avoid schema inference conflicts with Decimal
    history_write_df = budgets_forecast_df.copy()
    history_write_df["value"] = history_write_df["value"].astype(str)

    new_data_df = spark.createDataFrame(history_write_df) \
        .withColumn("value", F.col("value").cast(value_type))

    # If table exists with narrower decimal precision, widen by rewriting with union
    if spark.catalog.tableExists(target_table):
        existing_df = spark.table(target_table) \
            .withColumn("value", F.col("value").cast(value_type))
        existing_df.unionByName(new_data_df, allowMissingColumns=True) \
            .write.format("delta") \
            .mode("overwrite") \
            .option("overwriteSchema", "true") \
            .saveAsTable(target_table)
    else:
        new_data_df.write.format("delta") \
            .mode("append") \
            .saveAsTable(target_table)

    print(f"Budget/Forecast saved: {len(budgets_forecast_df)} rows → {target_table}")
    print(f"  Version: {version_id}")

save_budgets_forecast(final_df, catalog, silver_schema)

# COMMAND ----------

# DBTITLE 1,Section: Validation
# MAGIC %md
# MAGIC ## 7. Validation
# MAGIC Duplicate checks.
# MAGIC

# COMMAND ----------


# Check duplicates in budget_forecast for latest version
duplicates_bf = spark.sql(f"""
    SELECT metric_id, kpi_name, scenario, date_key, count(*) AS cnt
    FROM {catalog}.{silver_schema}.scr_budget_forecast
    WHERE CAST(SUBSTRING(kpi_id, 2) AS INT) < 9000
      AND version_id = (SELECT MAX(version_id) FROM {catalog}.{silver_schema}.scr_budget_forecast)
    GROUP BY ALL
    HAVING count(*) > 1
    ORDER BY count(*) DESC
""")
display(duplicates_bf)

# COMMAND ----------

# DBTITLE 1,validation

# Check duplicates in actuals_historic
duplicates_act = spark.sql(f"""
    SELECT metric_id, kpi_name, scenario, date_key, count(*) AS cnt
    FROM {catalog}.{silver_schema}.scr_actuals_historic
    WHERE CAST(SUBSTRING(kpi_id, 2) AS INT) < 9000
    GROUP BY ALL
    HAVING count(*) > 1
    ORDER BY count(*) DESC
""")
display(duplicates_act)