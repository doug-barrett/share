# SCR KPI Calculation Engine

## Overview
End-to-end KPI calculation pipeline for Evolution Mining's Mungari (MGO) SCR operations.
Processes KPI formulas through a dependency-ordered wave execution engine, producing
calculated KPI values written to Delta tables with version tracking, then syncs
downstream results to Azure SQL for the Triple-A (AAA) reporting platform.

## Architecture

```
scr_kpi_calculation_engine/
├── main.ipynb                  # Entry point notebook (orchestrator)
├── README.md                   # This file
├── requirements.txt            # Python dependencies (openpyxl, azure-identity, pytds)
├── env/                        # Environment config files
│   ├── dev.env
│   ├── sit.env
│   ├── uat.env
│   └── prod.env
└── src/
    ├── __init__.py             # Package exports
    ├── config.py               # Environment-based configuration (EngineConfig dataclass)
    ├── utils.py                # Utility functions (input_ref cleaning, overlays)
    ├── data_loader.py          # Data loading from UC tables & Excel files
    ├── engine.py               # Core calculation engine (wave execution)
    └── sql/
        └── vw_scr_report_snapshot  # Report snapshot view DDL
```

## Modules

### config.py
Environment-based configuration using `EngineConfig` dataclass. Settings are loaded
from `env/<env>.env` files, with Job parameters taking precedence at runtime.

**Configuration Resolution Order:**
1. Job `base_parameters` / widgets (non-empty value wins)
2. Value from `env/<env>.env` file
3. Hardcoded fallback default

**Fiscal Period Derivation:**
Calendar `year` and `month` are automatically converted using Evolution Mining's
July–June fiscal calendar:
- `month >= 7`: `fiscal_year = year + 1`, `fiscal_month = month - 6`
- `month < 7`: `fiscal_year = year`, `fiscal_month = month + 6`

**EngineConfig Fields:**
| Field | Source | Description |
| --- | --- | --- |
| `catalog` | env file | Unity Catalog name |
| `aaa_catalog` | env file | AAA SQL MI catalog |
| `bronze_schema` | env file | Schema for raw/source tables |
| `silver_schema` | env file | Schema for calculation output tables |
| `gold_schema` | env file | Schema for enriched views |
| `reference_schema` | env file | Schema for reference/master tables |
| `manual_schema` | env file | Schema for manual/overlay tables |
| `aaa_schema` | env file | Schema in AAA catalog |
| `scenario` | env file | Reporting scenario (ACTUAL, Budgets, Forecast) |
| `volume_base_path` | env file | Base path for Excel source files |
| `azsql_server` | env file | Azure SQL server |
| `azsql_database` | env file | Azure SQL database |
| `azsql_tenant_id` | env file | Azure AD tenant for service principal auth |
| `azsql_client_id` | env file | Service principal client ID |
| `azsql_secret_scope` | env file | Databricks secret scope |
| `azsql_secret_key` | env file | Secret key name |
| `site_code` | job param | Site identifier (e.g. `MGO`) |
| `fiscal_year` | derived | Derived from year/month (July–June calendar) |
| `fiscal_month` | derived | Derived from year/month (July–June calendar) |
| `year` | job param | Calendar year (default: today) |
| `month` | job param | Calendar month (default: today) |
| `reconcilor_file` | env file | Reconcilor Excel filename |
| `manual_file` | env file | Manual data Excel filename |
| `historical_file` | env file | Historical input Excel filename |
| `unmatched_file` | env file | Unmatched data Excel filename |
| `static_file` | env file | Static data Excel filename |
| `tb_adjustment_file` | env file | TB adjustment Excel filename |
| `kpi_adjustment_file` | env file | KPI adjustment Excel filename |
| `input_adjustment_file` | env file | Input adjustment Excel filename |

**Unity Catalog Tables (derived properties):**
| Table | Schema | Purpose |
| --- | --- | --- |
| `scr_calculation_engine_output_current` | silver | Latest KPI results (overwritten each run) |
| `scr_calculation_engine_output` | silver | Versioned history (append-only with version_id) |
| `scr_actuals_historic` | silver | Historical actuals for variance calculation |
| `scr_budget_forecast` | silver | Budget & forecast data for variance calculation |
| `unified_input_ref` | silver | Unified input reference values |
| `input_to_gl_account_table` | silver | GL account mapping for TB adjustments |
| `scr_trail_bal_mvmt` | silver | Trial balance movement staging |
| `pronto_gl_history_period` | bronze | Pronto GL history period (source) |
| `pronto_gl_master` | bronze | Pronto GL master (source) |
| `scr_mgo_kpi_master` | reference_data | KPI master definitions (SCD2, filtered by active_ind=1) |
| `scr_mgo_kpi_ref` | reference_data | KPI dimension reference |
| `scr_location_hierarchy` | reference_data | Location hierarchy |
| `scr_reconcilor_data` | manual_data | Reconcilor overlay data |
| `scr_manual_data` | manual_data | Manual overlay data |
| `scr_static_data` | manual_data | Static data |
| `scr_historical_input_data` | manual_data | Historical input data |
| `scr_unmatched_data` | manual_data | Unmatched data |
| `scr_kpi_adjustment_data` | manual_data | KPI adjustment data |
| `scr_tb_adjustment_data` | manual_data | TB adjustment snapshot (written each run) |
| `scr_input_adjustment_data` | manual_data | Input adjustment data |
| `vw_scr_calculation_engine_output_current_enriched` | gold | Enriched output view |
| `scr_trial_balance` | aaa_schema (aaa_catalog) | AAA source trial balance — read by `load_tb_adjustments_aaa` |
| `scr_value_adjustment` | aaa_schema (aaa_catalog) | KPI adjustment workflow — read by `load_scr_value_adjustment` |

**Azure SQL Target Tables** (Triple-A platform):
| Table | Description |
| --- | --- |
| `scr_value_adjustment` | KPI adjustment workflow (original/adjusted values, approval status) |
| `scr_variance` | Budget & forecast variance by KPI |
| `scr_audit_trail` | Change audit trail |
| `scr_annotation` | User annotations/commentary |

### utils.py
Reusable helpers:
- `clean_input_ref(series)` — Standardize input_ref values (strip, translate unicode subscripts)
- `clean_kpi_df(df)` — Strip whitespace from all string columns
- `merge_excel_overlay(base_df, overlay_df)` — Merge overlay into base (overwrite matching, append new)
- `check_duplicates(df)` — Log warning if duplicate keys found

### data_loader.py
Data loading from Unity Catalog and Excel sources.

**Key Functions:**
- `write_excel_to_delta(spark, path, table, config)` — Read Excel → add date_key → clean columns → write to Delta
- `load_kpi_master(spark, config)` — Load active KPIs (active_ind=1) + kpi_ref from catalog
- `load_location_hierarchy(spark, config)` — Load location hierarchy from catalog
- `load_unified_inputs(spark, config)` — Load unified_input_ref filtered by fiscal period
- `load_reconcilor_and_manual(spark, config)` — Load Reconcilor + Manual + Static from Excel → Delta, rename `SCR_Value` → `value`
- `load_historical_data(spark, config)` — Load historical inputs from Excel → Delta
- `load_tb_adjustments(spark, config)` — Load TB adjustments from Excel; direct `input_ref + value` format with GL account merge
- `load_tb_adjustments_aaa(spark, config)` — Load TB adjustments from AAA `scr_trial_balance` Delta table; filters by month/year/site_code, casts `adjustment` and `current_movement` to `DECIMAL(36,12)`, writes Spark DataFrame directly to `scr_tb_adjustment_data` (preserving DECIMAL types), then joins to `input_to_gl_account_table` to produce adjusted input values
- `load_input_adjustments(spark, config)` — Load manual input adjustments from Excel → Delta
- `load_kpi_adjustments(spark, config)` — Load KPI-level adjustments from Excel → Delta, returns `{key: value}` dict
- `load_scr_value_adjustment(spark, config)` — Load KPI adjustments from AAA `scr_value_adjustment` catalog table, returns `{key: value}` dict
- `load_all_inputs(spark, config)` — Orchestrator: returns `(inputs_df, kpi_master_df, kpi_ref_df, kpi_adjustments)`

**Data Flow:**
1. Load `kpi_master` (active_ind=1) and `kpi_ref` from Delta
2. Load `unified_input_ref` filtered by fiscal_year/fiscal_month
3. Overlay: Reconcilor + Manual + Static Excel → Delta → merge into inputs
4. Overlay: Historical Excel → Delta → merge into inputs
5. Overlay: Input adjustments Excel → Delta → merge into inputs (errors logged, non-blocking)
6. Overlay: TB adjustments from AAA `scr_trial_balance` (via `load_tb_adjustments_aaa`) — Spark DataFrame written directly to `scr_tb_adjustment_data` preserving `DECIMAL(36,12)`, then joined to `input_to_gl_account_table` → merge into inputs
7. Load KPI adjustments from AAA `scr_value_adjustment` table (or Excel in `ba` env / specific periods)

**Note on DECIMAL precision (`load_tb_adjustments_aaa`):**
The `adjustment` and `current_movement` columns are cast to `DECIMAL(36,12)` in Spark.
The Delta write uses the Spark DataFrame directly — **not** a pandas round-trip — because
converting to pandas first would silently downcast DECIMAL to `float64`, losing the
declared precision in the stored Delta table schema.

### engine.py
Core calculation engine:
- **Wave-based execution** ordered by `execution_level` (topological sort)
- **Formula resolution**: K-reference (KPI dependency) and I-reference (input) substitution
- **KPI adjustment application**: Post-calculation adjustments from AAA
- **Missing dependency tracking**: Logs unresolved references (defaults to 0)
- **Output enrichment**: `kpi_engine_key` (SHA-256 hash), `dim_name` mapping, `resolved_formula_names`

**Key Functions:**
- `build_kpi_ref_dict_map()` — Converts DataFrame or dict to `{int: str}` mapping
- `build_lookup()` — Creates `(kpi_id, kpi_dim_id) → value` lookup from results
- `replace_kpis()` — Substitutes K/I references in formulas with resolved values
- `eval_formula()` — Safely evaluates resolved formula strings
- `run_calculation_engine()` — Main orchestrator (wave execution, adjustments, output assembly)

**Output Columns:**
`kpi_engine_key`, `matrix_id`, `date_key`, `fiscal_year`, `fiscal_month`, `kpi_id`,
`kpi_dim_id`, `dim_name`, `sort_key`, `execution_level`, `category`, `subcategory`,
`kpi_name`, `python_formula`, `uom`, `value`, `resolved_formula`, `resolved_formula_names`

## Pipeline Steps (main.ipynb)

| Cell | Title | Description |
| --- | --- | --- |
| 1 | KPI Calculation Engine Overview | Markdown header and architecture summary |
| 2 | Install dependencies | `%pip install -r ./requirements.txt` |
| 3 | Step 0 - Read job and run IDs | Read `job_id`/`run_id` from widget params (serverless-compatible) |
| 4 | Setup sys.path and imports | Add project root to path, import modules |
| 5 | Initialize configuration | Load job params with defaults, create `EngineConfig` from env file |
| 6 | Step 1 - Load all input data | Unified inputs + Excel overlays via `load_all_inputs()` |
| 7 | Step 2 - Build kpi_ref_dict | Dimension ID → name mapping, write to `scr_mgo_kpi_ref` |
| 8 | Step 3 - Run calculation engine | Wave execution, formula resolution, KPI adjustments |
| 9 | Step 4 - Write current results | Overwrite `scr_calculation_engine_output_current` |
| 10 | Step 5 - Append versioned history | Append to history table with auto-incrementing `version_id` |
| 11 | Step 6 - Log missing dependencies | Report unresolved formula references |
| 12 | Init — Dependencies and Config | Azure SQL dependencies + helpers for cell 13 |
| 13 | Step 7 - Build and MERGE to Azure SQL | Build 4 DataFrames and MERGE to Azure SQL |
| 14 | Pipeline Exit | Return success message with KPI count |

## Azure SQL Sync

After the KPI calculation completes, the pipeline builds and pushes 4 tables to the
Triple-A Azure SQL database using `pytds` with Azure AD service principal authentication.

**MERGE Strategy:**
- `WHEN MATCHED` → UPDATE engine-derived columns only (preserves user edits in AAA)
- `WHEN NOT MATCHED` → INSERT new row
- Never DELETE or TRUNCATE

**Enrichment during build:**
- `site_code`, `company_code` → from gold enriched view (`kpi_engine_key` join)
- `unit_of_measure` → union of actuals_historic, budget_forecast, and engine uom
- `kpi_aggregation` → actual KPI name (not BASE/CALCULATED)

**Tables built:**
| Azure SQL Table | Source Logic |
| --- | --- |
| `scr_value_adjustment` | Engine output with adjustment workflow columns |
| `scr_variance` | Current + historical month budget/forecast variance |
| `scr_audit_trail` | Change tracking |
| `scr_annotation` | User commentary |

## Usage

### As a Scheduled Job
The pipeline runs as Databricks Job `SCR KPI Calculation Engine - Dev` (ID: `130350402661888`),
scheduled monthly on the 1st at 6:00 AM AEST.

**Job `base_parameters`:**
```
env: dev
month: 4
year: 2026
job_id: {{job.id}}
run_id: {{job.run_id}}
```

The `env` parameter selects the environment file (`dev.env`, `sit.env`, `uat.env`, `prod.env`).
Override `month`/`year` to target a different reporting period. Fiscal period is derived automatically.

The `job_id` and `run_id` parameters use Databricks **dynamic value references** — they resolve
at runtime to the actual job-level IDs. This is required on serverless compute where
`context.tags()`, `spark.conf.get()` for job keys, and `dbutils.jobs` methods are all blocked
by the Py4J security whitelist.

### Interactive
Run `main.ipynb` directly on serverless compute. Defaults to `env=dev`, `month=4`, `year=2026`
when widgets are not set. Job ID and Run ID will show as `None` (expected).

### Serverless Compute Notes
On Databricks serverless compute, the following standard approaches for reading job context
are **not available**:
- `dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags()` — blocked by Py4J whitelist
- `spark.conf.get("spark.databricks.job.id")` — throws `CONFIG_NOT_AVAILABLE`
- `dbutils.jobs.jobId()` / `dbutils.jobs.runId()` — methods do not exist (`JobsHandler` only exposes `taskValues`)
- `os.environ['DATABRICKS_JOB_ID']` — not set

The solution is to pass `job_id: {{job.id}}` and `run_id: {{job.run_id}}` as job `base_parameters`
and read them via `dbutils.widgets.getAll()`.

## Data Flow
```
┌─────────────────────────────────────────────────────────────┐
│                     INPUT SOURCES                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  UC: scr_mgo_kpi_master ─── data_loader ──→ kpi_master_df   │
│      (active_ind = 1)                                       │
│                                                             │
│  UC: unified_input_ref ──── data_loader ──┐                 │
│  Excel: reconcilor_data ──────────────────┤                 │
│  Excel: business_manual_data ─────────────┤                 │
│  Excel: static_data ──────────────────────┼──→ inputs_df    │
│  Excel: historical_input_data ────────────┤                 │
│  Excel: input_adjustments ────────────────┤                 │
│  AAA:   scr_trial_balance (+ GL join) ────┘                 │
│                                                             │
│  AAA: scr_value_adjustment ── data_loader ─→ kpi_adjustments│
│  (aaa_catalog.aaa_schema.scr_value_adjustment)              │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
                 ┌─────────────────────────┐
                 │   engine.run()          │
                 │  (wave execution)       │
                 └─────────────────────────┘
                            │
                            ▼
         ┌──────────────────────────────────────┐
         │        DELTA OUTPUT TABLES            │
         ├──────────────────────────────────────┤
         │  silver.scr_calculation_engine_       │
         │       output_current (overwrite)      │
         │  silver.scr_calculation_engine_       │
         │       output (append + version_id)    │
         │  reference_data.scr_mgo_kpi_ref       │
         │       (dimension reference)           │
         └──────────────────────────────────────┘
                            │
                            ▼
         ┌──────────────────────────────────────┐
         │     AZURE SQL (Triple-A Platform)     │
         ├──────────────────────────────────────┤
         │  scr_value_adjustment (MERGE)         │
         │  scr_variance (MERGE)                 │
         │  scr_audit_trail (MERGE)              │
         │  scr_annotation (MERGE)               │
         │                                       │
         │  Auth: Azure AD Service Principal      │
         │  Driver: pytds                         │
         └──────────────────────────────────────┘
```

## Environment Files

Each environment has a `.env` file in the `env/` folder:

| File | Catalog | Volume Path |
| --- | --- | --- |
| `dev.env` | `enterprise_data_platform_dev` | `/Volumes/enterprise_data_platform_dev/landing/dataconnect/mungari` |
| `ba.env` | `enterprise_data_platform_analysis` | `/Volumes/enterprise_data_platform_analysis/landing/dataconnect/mungari` |
| `sit.env` | `enterprise_data_platform_sit` | `/Volumes/enterprise_data_platform_sit/landing/dataconnect/mungari` |
| `uat.env` | `enterprise_data_platform_uat` | `/Volumes/enterprise_data_platform_uat/landing/dataconnect/mungari` |
| `prod.env` | `enterprise_data_platform` | `/Volumes/enterprise_data_platform/landing/dataconnect/mungari` |

## Version History
The history table (`scr_calculation_engine_output`) appends results with an
auto-incrementing `version_id` per `date_key`, allowing full audit trail of
recalculations for the same period.
