# Databricks notebook source
# MAGIC %pip install -r ./requirements.txt --quiet
# MAGIC # ============================================================
# MAGIC # All imports (consolidated, deduplicated)
# MAGIC # ============================================================
# MAGIC
# MAGIC # Standard library
# MAGIC import sys
# MAGIC import os
# MAGIC import time
# MAGIC import math
# MAGIC import importlib
# MAGIC from datetime import datetime
# MAGIC
# MAGIC # Third-party
# MAGIC import pytds
# MAGIC import certifi
# MAGIC import pandas as pd
# MAGIC import azure.identity
# MAGIC from azure.identity import ClientSecretCredential
# MAGIC
# MAGIC # PySpark
# MAGIC from pyspark.sql import functions as F
# MAGIC from pyspark.sql.types import (
# MAGIC     StringType, StructType, StructField, DoubleType,
# MAGIC     IntegerType, TimestampType
# MAGIC )
# MAGIC
# MAGIC # Project modules
# MAGIC import src.config
# MAGIC import src.utils
# MAGIC from src.config import create_config
# MAGIC from src.utils import azure_init

# COMMAND ----------

# DBTITLE 1,All imports (consolidated, deduplicated)


# Add project root to path
notebook_path = os.path.dirname(
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
)
project_root = f"/Workspace{notebook_path}"
if project_root not in sys.path:
    sys.path.insert(0, project_root)




# COMMAND ----------

# DBTITLE 1,Initialize configuration
importlib.reload(src.config)
from src.config import create_config

# Get env from job base_parameters; default to 'dev' for interactive runs
try:
    params = dbutils.widgets.getAll()
    env = params.get("env", "dev")
except Exception:
    params = {}
    env = "dev"

params.setdefault("env", "dev")
params.setdefault("month", "6")
params.setdefault("year", "2026")
config = create_config(params)

print(f"Environment:  {params.get('env', 'dev')}")
print(f"Catalog:      {config.catalog}")
print(f"Catalog:      {config.silver_schema}")
print(f"Fiscal Year:  {config.fiscal_year}  |  Fiscal Month: {config.fiscal_month}")
print(f"Year:         {config.year}  |  Month: {config.month}")

# COMMAND ----------

# DBTITLE 1,Cell 3
ghp_df = spark.table(f"{config.catalog}.{config.bronze_schema}.mungari_pronto_gl_history_period")
master_df = spark.table(f"{config.catalog}.{config.bronze_schema}.mungari_pronto_gl_master")

# Create cte_gl_movements equivalent
cte_gl_movements_df = (
    ghp_df.filter(ghp_df.glhp_year == config.fiscal_year-1)
    .groupBy(
        F.trim(ghp_df.glhp_accountcode).alias("AccountCode")
    )
    .agg(
        F.sum(
            F.when(
                (ghp_df.glhp_year == config.fiscal_year-1) & (ghp_df.glhp_period == config.fiscal_month),
                ghp_df.glhp_amount
            ).otherwise(0)
        ).alias("CurrentPeriodMovement"),
        F.sum(
            F.when(
                (ghp_df.glhp_year == config.fiscal_year-1) & (ghp_df.glhp_period < config.fiscal_month),
                ghp_df.glhp_amount
            ).otherwise(0)
        ).alias("OpeningBalance")
    )
)

# Final select and join
result_df = (
    cte_gl_movements_df.alias("m")
    .join(
        master_df.withColumn("AccountCode", F.trim(master_df.gl_accountcode)),
        on="AccountCode",
        how="inner"
    ) 
    .select(
        F.col("m.AccountCode").alias("account_number"),
        F.trim(F.col("gl_desc")).alias("account_name"),
        F.col("m.OpeningBalance").cast("decimal(36,12)").alias("opening_balance"),
        F.col("m.CurrentPeriodMovement").cast("decimal(36,12)").alias("movement"),
        (F.col("m.OpeningBalance") + F.col("m.CurrentPeriodMovement")).cast("decimal(36,12)").alias("closing_balance"),
        F.when(F.col("m.AccountCode").substr(1, 2).isin("51", "31"),F.lit("MGO")).alias("site_code"),
        F.lit(config.fiscal_year).alias("fiscal_year"),
        F.lit(config.fiscal_month).alias("fiscal_month"),
        F.lit(config.year).alias("year"),
        F.lit(config.month).alias("month"),
        F.current_timestamp().alias("created_date")
    )
    .orderBy(F.col("m.AccountCode"))
)


result_df.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(f"{config.scr_trial_bal_mvmt_table}")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from enterprise_data_platform_dev.silver.scr_trial_bal_mvmt limit 5

# COMMAND ----------

# DBTITLE 1,Init - Dependencies and Config
# ============================================================
# Cell 1 — Init: Dependencies, Config, Helpers
# ============================================================

# --- NotebookUtils (reusable across notebooks) ---
importlib.reload(src.utils)
from src.utils import azure_init

nb = azure_init(config, spark)
nb.print_config()
nb.verify_tables()

# --- Backward-compatible aliases (used by downstream cells) ---
reporting_month   = nb.reporting_month
scenario          = nb.scenario
AZSQL_SCHEMA_NAME = nb.azsql_schema
start_timer       = nb.start_timer
end_timer         = nb.end_timer

print("✓ Init complete")


# Read from source table for specified month and year
src_df = spark.table(config.scr_trial_bal_mvmt_table) \
    .filter(
        (F.col("month") == config.month) &
        (F.col("year") == config.year)
    )



# COMMAND ----------

# DBTITLE 1,Step 7 - MERGE to Azure SQL scr_trial_balance
# ============================================================
# Step 7 — MERGE src_df into Azure SQL: edp_aaa.scr_trial_balance
# ============================================================
start_timer('merge_trial_balance')

# ── 1. Connect to Azure SQL ──────────────────────────────────
_cred = ClientSecretCredential(
    config.azsql_tenant_id,
    config.azsql_client_id,
    dbutils.secrets.get(config.azsql_secret_scope, config.azsql_secret_key)
)
_conn = pytds.connect(
    dsn=config.azsql_server, database=config.azsql_database,
    port=1433,
    access_token_callable=lambda: _cred.get_token("https://database.windows.net/.default").token,
    cafile=certifi.where(), autocommit=True
)
_cur = _conn.cursor()
print(f"✓ Connected to Azure SQL [{AZSQL_SCHEMA_NAME}]")

# ── 2. Select only columns that exist in target table ───────
# Target columns (excluding 'id' which is identity/auto-increment):
# Cast account_number to bigint — filter out non-numeric codes (target is bigint)
merge_df = src_df.withColumn("_acct_bigint", F.expr("try_cast(account_number as bigint)"))
_total = merge_df.count()
merge_df = merge_df.filter(F.col("_acct_bigint").isNotNull())
_kept = merge_df.count()
print(f"  Filtered: {_total - _kept} non-numeric account_numbers excluded ({_kept} rows retained)")

merge_df = merge_df.select(
    F.col("_acct_bigint").alias("account_number"),
    F.col("account_name"),
    F.col("opening_balance").cast("decimal(18,2)"),
    F.col("movement").cast("decimal(18,2)"),
    F.col("closing_balance").cast("decimal(18,2)"),
    F.col("site_code"),
    F.col("year"),
    F.col("month")
)
pdf = merge_df.toPandas()
print(f"  Rows to merge: {len(pdf):,}")

if len(pdf) == 0:
    print("  ─ No rows to merge, skipping.")
else:
    # ── 3. Build temp table and insert ───────────────────────
    _sanitise = nb.sanitise
    _sql_type = nb.sql_type

    tbl = "scr_trial_balance"
    merge_keys = ["account_number", "year", "month","site_code"]
    cols = list(pdf.columns)

    tmp = "#tmp_scr_trial_bal"
    _cur.execute(f"IF OBJECT_ID('tempdb..{tmp}') IS NOT NULL DROP TABLE {tmp}")

    col_dtypes = {c: _sql_type(pdf[c].dtype) for c in cols}
    col_positions = {c: pdf.columns.get_loc(c) for c in cols}
    col_defs = ', '.join(f'[{c}] {col_dtypes[c]}' for c in cols)
    _cur.execute(f"CREATE TABLE {tmp} ({col_defs})")

    rows = [tuple(_sanitise(row[col_positions[c]]) for c in cols) for row in pdf.itertuples(index=False, name=None)]
    sql_ins = f"INSERT INTO {tmp} ({', '.join(f'[{c}]' for c in cols)}) VALUES ({', '.join(['%s'] * len(cols))})"
    for i in range(0, len(rows), 1000):
        _cur.executemany(sql_ins, rows[i:i+1000])
    print(f"  ✓ Temp table loaded ({len(rows):,} rows)")

    # ── 4. MERGE statement ───────────────────────────────────
    update_cols = [c for c in cols if c not in merge_keys]
    merge_sql = f"""
        MERGE [{AZSQL_SCHEMA_NAME}].[{tbl}] AS t USING {tmp} AS s
        ON {' AND '.join(f't.[{k}] = s.[{k}]' for k in merge_keys)}
        WHEN MATCHED THEN
            UPDATE SET {', '.join(f't.[{c}] = s.[{c}]' for c in update_cols)}
        WHEN NOT MATCHED THEN
            INSERT ({', '.join(f'[{c}]' for c in cols)})
            VALUES ({', '.join(f's.[{c}]' for c in cols)});
    """
    _cur.execute(merge_sql)
    print(f"  ✓ MERGE complete")

    # ── 5. Cleanup and validate ──────────────────────────────
    _cur.execute(f"DROP TABLE {tmp}")
    _cur.execute(f"SELECT COUNT(*) FROM [{AZSQL_SCHEMA_NAME}].[{tbl}]")
    total = _cur.fetchone()[0]
    print(f"  ✓ {tbl}: {len(pdf):,} merged → {total:,} total rows in target")

_conn.close()
end_timer('merge_trial_balance')
print("✓ Azure SQL merge complete")