# Databricks notebook source
pip install openpyxl 

# COMMAND ----------

# Add project root to path and import modules
import sys
import os

notebook_path = os.path.dirname(
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
)
project_root = f"/Workspace{notebook_path}"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from src.config import create_config
from src.data_loader import load_all_inputs
from src.engine import run_calculation_engine

print(f"Project root: {project_root}")

# COMMAND ----------

from datetime import date
from src.config import create_config
from src.utils import create_views
import pandas as pd
try:
    params = dbutils.widgets.getAll()
except Exception:
    params = {}

params.setdefault("env", "dev")
params.setdefault("month", str(date.today().month))
params.setdefault("year", str(date.today().year))
params.setdefault("site_code", "MGO")
cfg = create_config(params)
print(f"Environment: {params['env']} | Catalog: {cfg.catalog} | Year: {cfg.fiscal_year}")

# COMMAND ----------

# DBTITLE 1,Load Excel files to Delta tables
import re
import pandas as pd
from pyspark.sql.functions import lit

pbi_path = cfg.pbi_templates_excel_path
print(f"PBI templates path: {pbi_path}")

pbi_sheet_names = [
    'Exec Template', 'Variance Template', 'Actual Template',
    'Actual MGO', 'Actual GEM', 'Budget', 'Budget MGO', 'Budget GEM',
    'Forecast', 'Forecast GEM', 'Forecast MGO', 'Actuals',
    'One Template','Variance New', 'Input MGO',
]

dfs = []
for sheet in pbi_sheet_names:
    # Read column names via pandas (avoids Analyze RPC on Spark DF inside loop)
    df = spark.read.option("dataAddress", sheet).option("headerRows", 1).excel(pbi_path)
    df = df.toDF(*[re.sub(r'\s+', ' ', c.strip()) for c in df.columns])
    if sheet == 'Exec Template':
        df = df.withColumns({"Subsection": lit(None)})
    dfs.append(df)

combined_df = dfs[0]
for df in dfs[1:]:
    combined_df = combined_df.unionByName(df, allowMissingColumns=True)

# Compute columns once outside any loop for final rename
final_cols = combined_df.columns
combined_df = combined_df.toDF(*[
    re.sub(r'[\s,;{}()\n\t=]+', '_', c).strip('_') for c in final_cols
])

pbi_table = f"{cfg.catalog}.{cfg.gold_schema}.pbi_report_templates"
combined_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(pbi_table)
print(f"PBI templates written: {len(pbi_sheet_names)} sheets → {pbi_table}")

# COMMAND ----------

# DBTITLE 1,Pronto mapping → bronze
import pandas as pd
from pyspark.sql.functions import col, trim, when, lit, current_timestamp

pronto_path = cfg.pronto_mapping_excel_path
print(f"Pronto mapping path: {pronto_path}")

excel_file = pd.ExcelFile(pronto_path)
pronto_sheet_names = excel_file.sheet_names
print(f"Sheets found: {pronto_sheet_names}")

for sheet in pronto_sheet_names:
    df_pd = pd.read_excel(excel_file, sheet_name=sheet, dtype=str, keep_default_na=True, na_filter=True)
    # Use pandas columns before creating Spark DF (avoids Analyze RPC inside loop)
    columns = list(df_pd.columns)
    df_spark = spark.createDataFrame(df_pd)
    df_spark = df_spark.withColumns({
        c: when(col(c).isNull(), lit(None))
           .when(trim(col(c).cast("string")) == "", lit(None))
           .otherwise(trim(col(c).cast("string")))
        for c in columns
    }).withColumns({
        "ingest_ts": current_timestamp(),
        "source_system": lit("KPI Catalog"),
    })
    table_name = f"{cfg.catalog}.{cfg.bronze_schema}.{sheet.lower().replace(' ', '_')}"
    df_spark.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)
    print(f"  Written: {table_name}")

print(f"Done — {len(pronto_sheet_names)} table(s) written to {cfg.catalog}.{cfg.bronze_schema}")